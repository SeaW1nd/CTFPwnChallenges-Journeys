#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

extern const char* BANNER;
extern const char* menu;

void sandbox();
void feedback();