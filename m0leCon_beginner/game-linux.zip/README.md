Do NOT modify any .py files in this directory if you do not want to make the Gabibbo angry.

Instead, you will have a greater time if you look under the `lib` directory.
